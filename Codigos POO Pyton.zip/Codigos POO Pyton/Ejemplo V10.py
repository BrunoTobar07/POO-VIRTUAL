class Cuenta:
    def __init__(self) :
        self._clave = "Informacion personal"
    
    def _informacion(self):
        print("Bruno Tobar,19 Años,Quito")

acceso= Cuenta()

print(acceso._informacion())

