class Aire_acondicionado():
    def __init__(self):
        self._estado ="Apagado"
        
    def encender(self):
        self._estado = "encendido"
        print("El aire acondicionado esta encendido")
        
    def cambio_de_temperatura(self):
        if self._estado == "Apagado":
            self.encender()
        print("Cambio la temperatura ")

aire_acondicionado = Aire_acondicionado()
aire_acondicionado.cambio_de_temperatura()
