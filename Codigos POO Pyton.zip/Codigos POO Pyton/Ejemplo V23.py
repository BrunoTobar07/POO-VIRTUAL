class Ave:
    pass
class Ave_Voladora(Ave):
    def volar(delf):
        return "Me encuentro volando"
    
    def planeat(delf):
        return "Estoy planeando"
    
class Ave_NO_Voladora(Ave):
    pass

