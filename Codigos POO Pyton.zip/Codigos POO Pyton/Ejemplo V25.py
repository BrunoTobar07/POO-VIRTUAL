from abc import ABC ,abstractmethod

class Verificacion_Ortografico (ABC):
    @abstractmethod
    def verificar_palabra(self,palabra):
        pass

class Diccionario (Verificacion_Ortografico):
    def verificar_palabra(self, palabra):
        # Logica para verificar palabras si esta en el diccionario
        pass

class Correcto_Ortografico:
    def __init__(self, verificador):
        self.verificador = verificador

    def corregir_texto (self,texto):
        #usamos el verificador para corregir el texto
        pass
