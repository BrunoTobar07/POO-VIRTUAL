class Brawler:
    def __init__(self, nombre,tipo, nivel_de_fuerza, daño):
        self.nombre = nombre
        self.tipo = tipo
        self.fuerza = nivel_de_fuerza
        self.daño = daño
    
    def __repr__(self):
        return f"{self.nombre}(Fuerza: {self.fuerza},Tipo : {self.tipo},Daño basico: {self.daño})"
    
    def __add__(self,otro_brawler):
        nuevo_nombre = self.nombre + "-"+ otro_brawler.nombre
        nueva_fuerza = round ((self.fuerza + otro_brawler.fuerza))
        nuevo_tipo = self.tipo + "-"+ otro_brawler.tipo
        nuevo_daño = round(self.daño + otro_brawler.daño)*3
        return Brawler(nuevo_nombre, nuevo_tipo,nueva_fuerza,nuevo_daño)

    
Sandy = Brawler("Sandy","Controlador",8,1600)
Buster = Brawler("Buster","Tanque",5,2800)
Chester = Brawler("Chester","Destructor",7,3100)


Sandy_Buster_Chester= Sandy + Buster + Chester
Sandy_Chester = Sandy + Chester
Buster_Chester = Buster + Chester
Buster_Sandy = Buster + Sandy


print(Sandy_Buster_Chester)
print(Sandy_Chester)
print(Buster_Chester)
print(Buster_Sandy)
