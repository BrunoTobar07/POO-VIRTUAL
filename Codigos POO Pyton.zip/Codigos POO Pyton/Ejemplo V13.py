def decorador(funcion):
    def funcion_modificada():
        print("Abrir puertas principales...")
        funcion()
        print("Cierre de las puertas...")
    return funcion_modificada

def entrada():
    print("Ingreso de las personas...") 

entrada_modificado = decorador(entrada)
entrada_modificado()

# @decorador
# def entrada():
#     print("Cierre de las puertas..")

# entrada()