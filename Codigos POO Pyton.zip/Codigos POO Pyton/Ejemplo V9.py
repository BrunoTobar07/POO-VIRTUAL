def orden_de_lista(nombres):
    for item in nombres:
        print(f"El orden actual de la lista es: {item}")


numeracion = [1,2,3,4,5]
nombres = ["Aguilar","Alvarez","Arias","Armijos","Arroyo"]

orden_de_lista(nombres)

orden_de_lista(numeracion)
