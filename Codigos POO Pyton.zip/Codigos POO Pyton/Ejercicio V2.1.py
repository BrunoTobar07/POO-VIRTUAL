class Animal:
    def comer(self):
        print("El animal esta comiendo")

class Marsupial(Animal):
    def cuidando(self):
        print("El animal esta cuidando a su cria")

class Mamifero(Animal): 
    def engendrar(self):
        print("El animal esta dando a luz")


class Canguro(Mamifero,Marsupial):
   pass

canguro = Canguro()

canguro.comer()
canguro.cuidando()
canguro.engendrar()

print(Canguro.mro())





