class Persona :
    def __init__(self, nombre, edad ,nacionalidad):
        self.nombre = nombre
        self.edad = edad
        self.nacionalidad =  nacionalidad
    
    def caminar(self):
        print("Hola, me encuentro caminando en este momento")

class Chef:
    def __init__(self,habilidad):
        self.habilidad = habilidad

    def mostrar_habilidad(self):
        return(f"Mi habilidad es : {self.habilidad}")


class Empleado_Chef(Persona,Chef):
    def __init__(self, nombre, edad, nacionalidad, habilidad, salario,empresa):
        Persona.__init__(self,nombre, edad, nacionalidad)
        Chef.__init__(self,habilidad)
        self.salario = salario
        self.empresa = empresa
    
    def presentarse(self):
        print(f'Hola soy:{self.nombre},{self.mostrar_habilidad()} y trabajo de {self.empresa} en Corteza-Udla')
    

Alejandro =Empleado_Chef("Alejandro","20","Colombiano","Cocinar","420","Cocinero")

Alejandro.presentarse()



