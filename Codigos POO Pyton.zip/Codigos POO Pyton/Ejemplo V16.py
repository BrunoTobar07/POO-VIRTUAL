class Persona:
    def __init__(self,nombre, edad):
        self.__nombre = nombre
        self._edad = edad 

    @property
    def nombre(self):
        return self.__nombre
    
    @nombre.setter
    def nombre(self, nuevo_nombre):
        self.__nombre = nuevo_nombre
    
    @nombre.deleter
    def nombre(self):
        del self.__nombre

        

bruno = Persona ("Wilmer",34)

nombre= bruno.nombre
print(nombre)

bruno.nombre = "Mateo"

nombre= bruno.nombre
print(nombre)

del bruno.nombre

print("Sebastian")
