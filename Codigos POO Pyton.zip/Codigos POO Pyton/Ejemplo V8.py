num1=5
num2=3.2
num3= 2.4

resultado = num1 +num2 +num3 -num1
print(resultado)
print(type(resultado))