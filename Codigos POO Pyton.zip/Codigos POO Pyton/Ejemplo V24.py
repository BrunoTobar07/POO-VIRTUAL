from abc import ABC , abstractmethod

class C(ABC):

    @abstractmethod
    def comer(self):
        pass

class T(ABC):
    @abstractmethod 
    def trepar(self):
        pass

class D(ABC):
    @abstractmethod
    def dormir (self):
        pass

class Humano (C,T,D):
    def comer(self):
        print("El humano esta comiendo ")

    def trepar(self):
        print("El humano esta trepando ")

    def dormir(self):
        print("El humano esta durmiendo ")


class Tiburon (D):

    def dormir(self):
        print("El tiburon esta durmiendo ")

tiburon = Tiburon()
humano = Humano()

tiburon.dormir()
humano.trepar()