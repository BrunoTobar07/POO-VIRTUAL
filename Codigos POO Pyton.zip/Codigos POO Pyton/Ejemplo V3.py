class Telefono():
    def __init__(self, marca,modelo, camara):
        self.marca = marca
        self.modelo = modelo
        self.camara = camara
    
    def foto(self):
        print(f'Estas tomando una fotografia con una camara de : {self.camara}')

    def transferir(self):
        print(f'Estas transfiriendo archivos desde un : {self.marca} ')

telefono1 = Telefono("Huawei", "P40 Pro","50 MP") 
telefono2 = Telefono("Redmi","Note 10","45 MP")

telefono2.transferir()
telefono1.foto()

              