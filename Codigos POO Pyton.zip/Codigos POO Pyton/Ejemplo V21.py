class Tanque_de_conbustible:
    def __init__(self):
        self.combustible =100

    def agregar_combustible(self,cantidad):
        self.combustible += cantidad
    
    def obtener_conbustible(self):
        return self.combustible
    
    def usar_conbustible(self,cantidad):
        self.combustible -=cantidad

class Moto():
    def __init__(self,tanque):
        self.posicion = 0
        self.tanque = tanque
    
    def mover(self,distancia):
        if self.tanque.obtener_conbustible()>= distancia /2:
            self.posicion +=distancia
            self.tanque.usar_conbustible(distancia/2)
            print("Se a movido la moto exitosamente")
        else:
            print("No hay suficiente conbustible")
    
    def obtener_posicion(self):
        return self.posicion
    


tanque =Tanque_de_conbustible()
moto = Moto(tanque)

print(moto.obtener_posicion())
moto.mover(10)
print(moto.obtener_posicion())
moto.mover(50)
print(moto.obtener_posicion())
moto.mover(30)
print(moto.obtener_posicion())
moto.mover(50)
print(moto.obtener_posicion())
moto.mover(50)
print(moto.obtener_posicion())
moto.mover(50)
print(moto.obtener_posicion())