class Personaje:
    def __init__(self,nombre,daño,resistencia):
        self.nombre = nombre
        self.daño = daño
        self.resistencia = resistencia

    def __repr__(self):
        return f"{self.nombre}(Daño: {self.daño},Resistencia: {self.resistencia})"
    
    def __add__(self,otro_pj):
        nuevo_nombre = self.nombre + "-" + otro_pj.nombre
        nuevo_daño = round((self.daño +otro_pj.daño))*2
        nueva_resistencia = round(self.resistencia +otro_pj.resistencia)*2
        return Personaje(nuevo_nombre,nuevo_daño,nueva_resistencia)
    
def mostrar_personajes(personajes):
    if not personajes:
        print("No hay ningun personaje creado en este momento")
    else:
        print("Personajes disponibles: ")
        for i, personaje in enumerate(personajes):
            print(f"{i+1}.{personaje}")

def crear_personaje():
    nombre = input("Ingrese el nombre del personaje")
    daño = float(input ("Ingrese el daño del Personaje"))
    resistencia = float (input("Ingrese la resistencia del Personaje"))
    return Personaje(nombre,daño,resistencia)

personajes = []

while True:
    print("\n1. Crear Personaje")
    print("2. Fusionar Personajes")
    print("3. Mostrar Personajes")
    print("4. Salir")
    opcion = input ("Selecciona una opcion.")

    if opcion == "1":
        personaje_nuevo = crear_personaje()
        personajes.append(personaje_nuevo)
        print("El personaje se a creado con exito!")
    
    elif opcion == "2":
        if len(personajes) < 2:
            print("Se debe tener al menos dos personajes")
        else:
            mostrar_personajes(personajes)
            num_pj1 = int(input("Ingrese el numero del primer personaje:"))
            num_pj2 = int (input("Ingrese el numero del segundo personaje:"))
            
            if 1 <= num_pj1 <= len(personajes) and 1 <= num_pj2 <=len(personajes) and num_pj1 != num_pj2:
                personaje1 = personajes[num_pj1 - 1]
                personaje2 = personajes[num_pj2 - 1]
                personaje_fusionado = personaje1 +personaje2
                personajes.append(personaje_fusionado)
                print(f"¡Fusion completada El nuevo personaje es: {personaje_fusionado}")
            else:
                print("Seleccion invalida. Eliga personajes validos")
    elif opcion == "3":
        mostrar_personajes(personajes)
    
    elif opcion == "4":
        print("¡Hasta luego!")
        break
    
    else:
        print("Opcio invalidad, intente de nuevo con una opcion valida")

while True:
    input("Juego finalizado")



