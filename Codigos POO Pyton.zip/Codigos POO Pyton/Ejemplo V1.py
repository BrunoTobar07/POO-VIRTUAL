class Telefono():
    marca = "Huawei"
    modelo = "P40 Pro"
    camara = "50 MP"


telefono1 = Telefono()
telefono2 = Telefono()
telefono3 = Telefono()
telefono4 = Telefono()

print(telefono1.modelo)


     