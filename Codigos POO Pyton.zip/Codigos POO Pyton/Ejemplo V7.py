class Carro():
    def encender(self):
        return"Se encendio el automovil"
    
class Moto():
    def encender(self):
        return"Se encendio la motocicleta"
    
def encender_el_vehiculo(vehiculo):
    print(vehiculo.encender())

carro = Carro()
moto = Moto()

encender_el_vehiculo(carro)

print(moto.encender())
      