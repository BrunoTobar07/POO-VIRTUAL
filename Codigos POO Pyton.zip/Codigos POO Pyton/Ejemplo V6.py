class A:
    def ubicacion(self):
        print("Ubicacion desde el punto A")

class F:
    def ubicacion(self):
        print("Ubicacion desde el punto F")

class B(A):
    def ubicacion(self):
        print("Ubicacion desde el punto B")

class C(B):
    def ubicacion(self):
        print("Ubicacion desde el punto C")

class D(C,F):
    def ubicacion(self):
        print("Ubicacion desde el punto D")

d=D()

print(D.mro())
C.ubicacion(d)


