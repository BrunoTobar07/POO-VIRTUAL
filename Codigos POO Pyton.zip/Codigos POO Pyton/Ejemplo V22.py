class Transferir_dinero:
    def __init__(self, usuario,dinero):
        self.usuario =  usuario
        self.dinero = dinero

    def transferir(self):
        raise NotImplementedError
    
class Produbanco(Transferir_dinero):
    def transferir(self):
        print(f"Transferencia enviada a la cuenta de Produbanco de {self.usuario.produbanco}")

class Banco_Internacional(Transferir_dinero):
    def transferir(self):
        print(f"Transferencia enviada a la cuenta de Banco Internacional de {self.usuario.bancointernacional}")

class Banco_Pichincha(Transferir_dinero):
    def transferir(self):
        print(f"Transferencia enviada a la cuenta de Banco Pichincha de {self.usuario.bancopichincha}")        



