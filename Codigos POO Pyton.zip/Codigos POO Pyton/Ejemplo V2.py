class Telefono():
    def __init__(self, marca,modelo, camara):
        self.marca = marca
        self.modelo = modelo
        self.camara = camara

telefono1 = Telefono("Huawei", "P40 Pro","50 MP") 
telefono2 = Telefono("Redmi","Note 10","45 MP")

print(telefono1.modelo)
print(telefono2.camara)

