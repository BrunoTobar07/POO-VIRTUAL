/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_serviciodetransporte;

/**
 *
 * @author Evolve
 */
public class Pasajero extends Persona{
    
    public String id; 

    public Pasajero(String id, String nombre, int edad) {
        super(nombre, edad);
        this.id = id;
    }

    public Pasajero() {
    }
    
    public void pedirTaxi(){
        System.out.println("Metodo pedir");
    }
    
    public void cancelarTaxi(){
        System.out.println("Metodo cancelar");
    }
}