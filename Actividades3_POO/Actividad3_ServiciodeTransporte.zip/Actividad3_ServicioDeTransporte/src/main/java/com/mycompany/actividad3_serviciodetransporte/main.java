/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.actividad3_serviciodetransporte;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Evolve
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Pasajero psj = new Pasajero();
        Chofer chf = new Chofer();
        int band, edad, op;
        boolean b = true;
        do {
            try {

                System.out.println("\t Menu ");
                System.out.println("1. Pasajero");
                System.out.println("2. Chofer ");
                System.out.println("3. Mostrar Datos");
                System.out.println("4. Salir ");
                op = sc.nextInt();

                switch (op) {
                    case 1:
                        System.out.println("Ingrese nombre del Pasajero");
                        psj.nombre = sc.next();
                        band = 0;
                        do {
                            System.out.println("Ingrese edad del Pasajero");
                            edad = sc.nextInt();
                            if (edad > 0 && edad < 100) {
                                psj.edad = edad;
                                band = 1;
                            } else {
                                System.out.println("Edad fuera de rango");
                            }

                        } while (band == 0);

                        System.out.println("Ingrse CI del Pasajero");
                        psj.setCi(sc.next());
                        System.out.println("Ingrese ID del Pasajero");
                        psj.id = sc.next();

                        break;
                    case 2:

                        System.out.println("Ingrese nombre del Chofer");
                        chf.nombre = sc.next();
                        band = 0;
                        do {
                            System.out.println("Ingrese edad del Chofer");
                            edad = sc.nextInt();
                            if (edad > 0 && edad < 100) {
                                chf.edad = edad;
                                band = 1;
                            } else {
                                System.out.println("Edad fuera de rango");
                            }

                        } while (band == 0);

                        System.out.println("Ingrese CI del Chofer");
                        chf.setCi(sc.next());
                        System.out.println("Ingrese Nº Placa");
                        chf.placa = sc.next();
                        System.out.println("Ingrese codigo de taxi");
                        chf.codTaxi = sc.next();

                        break;
                    case 3:

                        System.out.println("Nombre Pasajero: " + psj.nombre);
                        System.out.println("Edad Pasajero: " + psj.edad);
                        System.out.println("Cedula Pasajero: " + psj.getCi());
                        System.out.println("Nº ID Pasajero: " + psj.id);
                        psj.pedirTaxi();
                        psj.cancelarTaxi();

                        System.out.println("");

                        System.out.println("Nombre Chofer: " + chf.nombre);
                        System.out.println("Edad Chofer: " + chf.edad);
                        System.out.println("Cedula Chofer:" + chf.getCi());
                        System.out.println("Nº Placa: " + chf.placa);
                        System.out.println("Codigo Taxi: " + chf.codTaxi);
                        chf.aceptarCarrera();
                        chf.cancelarCarrera();

                        break;
                    case 4:
                        System.out.println("Saliendo del sistema");
                        b = false;
                        break;
                    default:
                        System.out.println("Opcion incorrecta");

                }

            } catch (InputMismatchException e) {
                System.out.println("Tipo de datos con coinciden");
                sc.nextLine();
                System.out.println("");
            }

        }while(b);
    }

}
