/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_serviciodetransporte;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Evolve
 */
public class Chofer extends Persona {
    
    public String placa;
    public String codTaxi;

    public Chofer(String placa, String codTaxi, String nombre, int edad) {
        super(nombre, edad);
        this.placa = placa;
        this.codTaxi = codTaxi;
    }

    public Chofer() {
    }
    
    public void aceptarCarrera(){
        System.out.println("Metodo aceptar");
    }
    
    public void cancelarCarrera(){
        System.out.println("Metodo cancelar");
    }
}
