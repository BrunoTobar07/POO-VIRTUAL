/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_zoo;

/**
 *
 * @author Evolve
 */
public class Personas {
 public String nombre;
    public int edad;
    private String ci; 

    public Personas(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public Personas() {
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }
    
    
    
    public void comer(){
        
    }
    
    public void dormir(){
        
    }
    
}