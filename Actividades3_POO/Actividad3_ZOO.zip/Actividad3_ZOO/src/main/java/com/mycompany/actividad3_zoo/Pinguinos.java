/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_zoo;

/**
 *
 * @author Evolve
 */
public class Pinguinos extends Zoologico{

    public Pinguinos(String nombre, int edad) {
        super(nombre, edad);
    }

    public Pinguinos() {
    }
    
    public void nadar(){
        
    }
    
    public void pescar(){
        
    }
}
