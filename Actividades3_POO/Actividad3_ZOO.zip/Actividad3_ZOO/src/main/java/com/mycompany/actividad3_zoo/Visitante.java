/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_zoo;

/**
 *
 * @author Evolve
 */
public class Visitante extends Personas{
    public String numeroCarnet;

    public Visitante(String numeroCarnet, String nombre, int edad) {
        super(nombre, edad);
        this.numeroCarnet = numeroCarnet;
    }

    public Visitante() {
    }
    
    
    public void comprar(){
        
    }
    
}
