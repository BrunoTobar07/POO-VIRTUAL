/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_zoo;

/**
 *
 * @author Evolve
 */
public class Cuidadores extends Personas{
    
    public String numeroId;

    public Cuidadores(String numeroId, String nombre, int edad) {
        super(nombre, edad);
        this.numeroId = numeroId;
    }

    public Cuidadores() {
    }
    
    public void  alimentarAnimales(){
        
    }
}