/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_zoo;

/**
 *
 * @author Evolve
 */
public class Leon extends Zoologico{
    
    public boolean vacuna;

    public Leon(boolean vacuna, String nombre, int edad) {
        super(nombre, edad);
        this.vacuna = vacuna;
    }

    public Leon() {
    }
    
    public void rugir(){
        
    }
    
    public void cazar(){
        
    }
}

