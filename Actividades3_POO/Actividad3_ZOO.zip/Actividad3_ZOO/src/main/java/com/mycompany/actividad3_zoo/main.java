/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.actividad3_zoo;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Evolve
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        boolean b = true;
        Visitante visitante1 = new Visitante();
        Cuidadores cuidador1 = new Cuidadores();
        Leon leon = new Leon();
        Pinguinos pingui = new Pinguinos();
        int band, edad, op, op2;

        do {

            try {
                System.out.println("MENU");
                System.out.println("1.- Ingrese Persona");
                System.out.println("2.- Ingrese animales a Zoo");
                System.out.println("3.- Ver datos");
                System.out.println("4.- Salir");
                op = sc.nextInt();
                switch (op) {
                    case 1:
                        System.out.println("\tMENU PERSONA");
                        System.out.println("1.- Visitante");
                        System.out.println("2.- Cuidador");
                        op2 = sc.nextInt();
                        switch (op2) {
                            case 1:
                                band = 0;

                                System.out.println(" Nombre del Visitante");
                                visitante1.nombre = sc.next();
                                do {
                                    System.out.println(" Edad del Visitante");
                                    edad = sc.nextInt();
                                    if (edad > 0 && edad < 100) {
                                        visitante1.edad = edad;
                                        band = 1;
                                    } else {
                                        System.out.println("Edad NO valida");
                                    }

                                } while (band == 0);

                                System.out.println("Ingrese Cedula del Visitante");
                                visitante1.setCi(sc.next());
                                System.out.println("Ingrse N° Carnet del Visitante");
                                visitante1.numeroCarnet = sc.next();
                                break;
                            case 2:
                                System.out.println("Ingrese Nombre del Cuidador");
                                cuidador1.nombre = sc.next();
                                band = 0;
                                do {
                                    System.out.println("Ingrese Edad del Cuidador");
                                    edad = sc.nextInt();
                                    if (edad > 0 && edad < 100) {
                                        cuidador1.edad = edad;
                                        band = 1;
                                    } else {
                                        System.out.println("Edad NO valida");
                                    }

                                } while (band == 0);
                                System.out.println("Ingrese Cedula del Cuidador");
                                cuidador1.setCi(sc.next());
                                System.out.println("Ingrese ID del Cuidador");
                                cuidador1.numeroId = sc.next();
                                break;
                        }
                        break;
                    case 2:
                        System.out.println("\tMENU ZOO");
                        System.out.println("1.- Leon");
                        System.out.println("2.- Pinguino");
                        op2 = sc.nextInt();
                        switch (op2) {
                            case 1:
                                System.out.println("Ingrese Nombre del Leon");
                                leon.nombre = sc.next();
                                band = 0;
                                do {
                                    System.out.println("Ingrese Edad del Leon");
                                    edad = sc.nextInt();
                                    if (edad > 0 && edad < 80) {
                                        leon.edad = edad;
                                        band = 1;
                                    } else {
                                        System.out.println("Edad NO valida");
                                    }

                                } while (band == 0);
                                System.out.println("Ingrese N°de registro del Leon");
                                leon.setNumeroRegistro(sc.next());
                                System.out.println("Vacuna Del Leon");
                                leon.vacuna = sc.nextBoolean();
                                break;
                            case 2:
                                System.out.println("Ingrese Nombre del Pinguino");
                                pingui.nombre = sc.next();
                                band = 0;
                                do {
                                    System.out.println("Ingrese Edad del Pinguino");
                                    edad = sc.nextInt();
                                    if (edad > 0 && edad < 80) {
                                        pingui.edad = edad;
                                        band = 1;
                                    } else {
                                        System.out.println("Edad NO valida");
                                    }

                                } while (band == 0);
                                System.out.println("Ingrese N°de registro del Pinguino");
                                pingui.setNumeroRegistro(sc.next());
                                break;
                        }
                        break;
                    case 3:
                        System.out.println("Visitante");
                        System.out.println("Nombre: " + visitante1.nombre);
                        System.out.println("Edad: " + visitante1.edad);
                        System.out.println("Cedula: " + visitante1.getCi());
                        System.out.println("N° Carnet: " + visitante1.numeroCarnet);

                        System.out.println("Cuidador");
                        System.out.println("Nombre: " + cuidador1.nombre);
                        System.out.println("Edad: " + cuidador1.edad);
                        System.out.println("Cedula: " + cuidador1.getCi());
                        System.out.println("N° ID: " + cuidador1.numeroId);

                        System.out.println("Leon");
                        System.out.println("Nombre: " + leon.nombre);
                        System.out.println("Edad: " + leon.edad);
                        System.out.println("N° registro: " + leon.getNumeroRegistro());
                        System.out.println("Vacuna: " + leon.vacuna);

                        System.out.println("Pinguino");
                        System.out.println("Nombre: " + pingui.nombre);
                        System.out.println("Edad: " + pingui.edad);
                        System.out.println("N° registro: " + pingui.getNumeroRegistro());
                        break;
                    case 4:
                        System.out.println("Saliendo");
                        b = false;
                        break;
                    default:
                        System.out.println("Dato erroneo");
                }

                
            } catch (InputMismatchException ex) {
                System.out.println("Error");
                sc.nextLine();

            }

        } while (b);
    
    }
    
}
