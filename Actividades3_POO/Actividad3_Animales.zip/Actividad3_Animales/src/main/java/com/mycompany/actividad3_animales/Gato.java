/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_animales;

/**
 *
 * @author Evolve
 */
public class Gato extends Animales{
    
    public String colorPelo;

    public Gato(String colorP, String nombre) {
        super(nombre);
        this.colorPelo = colorP;
    }

    public Gato() {
    }
    
    public void treparArbol(){
        System.out.println("metodo");
    }
    
    public void cazarRaton(){
        System.out.println("metodo");
    }
    
}
