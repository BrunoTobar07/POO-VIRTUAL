/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad3_animales;

/**
 *
 * @author Evolve
 */
public class Perro extends Animales{
    
    public String raza;

    public Perro(String raza, String nombre) {
        super(nombre);
        this.raza = raza;
    }

    public Perro() {
    }
    
    public void correr(){
        System.out.println("metodo");
    }
    
    public void jugar(){
        System.out.println("metodo");
    }
}