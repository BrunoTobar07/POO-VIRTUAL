/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad3_animales;

import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author Evolve
 */
public class Actividad3_Animales {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean bl = true;
        Gato gt = new Gato();
        Perro pr = new Perro();
        int bandera, edad, op;
        
        do {
            try {

                System.out.println(" Menu ");
                System.out.println("1. Gato");
                System.out.println("2. Perro ");
                System.out.println("3. Mostrar Datos");
                System.out.println("4. Salir ");
                op = sc.nextInt();

                switch (op) {
                    case 1:
                        bandera = 0;

                        System.out.println("Ingrese nombre Gato ");
                        gt.nombre = sc.next();
                        
                        do {
                            System.out.println("Ingrese edad Gato ");
                            edad = sc.nextInt();
                            if (edad > 0 && edad < 20) {
                                gt.setEdad(edad);
                                bandera = 1;
                            } else {
                                System.out.println("Edad NO valida");
                            }

                        } while (bandera == 0);

                        System.out.println("Color de pelo del Gato ");
                        gt.colorPelo = sc.next();

                        break;
                    case 2:

                        System.out.println("Ingrese nombre del Perro ");
                        pr.nombre = sc.next();
                        bandera = 0;

                        do {
                            System.out.println("Ingrese edad del Perro ");
                            edad = sc.nextInt();
                            if (edad > 0 && edad < 20) {
                                pr.setEdad(edad);
                                bandera = 1;
                            } else {
                                System.out.println("Edad NO valido");
                            }

                        } while (bandera == 0);

                        System.out.println("Ingrese la raza del Perro ");
                        pr.raza = sc.next();

                        break;
                    case 3:
                        
                            System.out.println("Nombre Gato: " + gt.nombre);
                            System.out.println("Edad Gato: " + gt.getEdad());
                            System.out.println("Color pelo del Gato: " + gt.colorPelo);
                            gt.cazarRaton();
                            gt.treparArbol();

                            System.out.println("Nombre Perro: " + pr.nombre);
                            System.out.println("Edad Perro: " + pr.getEdad());
                            System.out.println("Raza Perro: " + pr.raza);
                            pr.correr();
                            pr.jugar();
                      
                        break;
                    case 4:
                        System.out.println("Saliendo");
                        bl = false;
                        break;
                    default:
                        System.out.println("Opcion Incorrecta");
                }

            } catch (InputMismatchException x) {
                System.out.println("Error");
                sc.nextLine();
            }
        } while (bl);

    }

}

