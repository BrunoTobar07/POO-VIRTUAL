/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad_de_aprendizaje_7_dic;

/**
 *
 * @author Evolve
 */
public class Actividad_de_aprendizaje_7_dic {

    public static void main(String[] args) {
        
       DatosPersona persona01=new DatosPersona("Bruno", "Tobar", 19);
       persona01.setID("1727471516");
       System.out.println("Nombre: "+persona01.nombre);
       System.out.println("Apellido: "+persona01.apellido);
       System.out.println("Edad: "+persona01.edad);
       System.out.println("ID: "+persona01.getID());
        
    }
}
