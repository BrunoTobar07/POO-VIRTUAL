/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad_de_aprendizaje_7_dic;

/**
 *
 * @author Evolve
 */
public class DatosPersona {
    
    public String nombre;
    public String apellido;
    public int edad;
    private String ID;

    public DatosPersona() {
    }
    

    public DatosPersona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    
  
}
