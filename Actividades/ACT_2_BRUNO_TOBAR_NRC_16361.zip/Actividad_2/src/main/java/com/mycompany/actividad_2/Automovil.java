/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad_2;

/**
 *
 * @author Evolve
 */
public class Automovil extends vehiculo{

    public Automovil(String marca, String año, String motor) {
        super(marca, año,motor   );
    }

    public Automovil() {
    }
    
    public void funcionamientoAmortiguadores(){
        System.out.println("Reparacion de Amortiguadores");
    }
}
