/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad_2;

/**
 *
 * @author Evolve
 */
public class Motocicleta extends vehiculo{

    public Motocicleta(String marca, String año, String motor) {
        super(marca, año, motor);
    }

    public Motocicleta() {
    }
    
    public void cuidadofrenos(){
        System.out.println("Proceso de cuidado de frenos");
    }
}
