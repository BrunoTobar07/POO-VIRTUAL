/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad_2;

/**
 *
 * @author Evolve
 */
public class Actividad_2 {

    public static void main(String[] args) {
        Automovil c1=new Automovil("Toyota", "2018", "Electrico");
        c1.setfrenos("Disco");
        System.out.println("Marca "+c1.marca);
        System.out.println("Año "+c1.año);
        System.out.println("Motor "+c1.motor);
        System.out.println("Frenos "+c1.getfrenos());
        c1.funcionamientoAmortiguadores();
        
        Motocicleta m1=new Motocicleta("Suzuki", "2022", "Gasolina");
        m1.setfrenos("Tambor");
        System.out.println("Marca "+m1.marca);
        System.out.println("Año "+m1.año);
        System.out.println("Motor "+m1.motor);
        System.out.println("Frenos "+m1.getfrenos());
        m1.cuidadofrenos();
    }
}
