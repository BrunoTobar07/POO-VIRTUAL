/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actividad_2;

/**
 *
 * @author Evolve
 */
public abstract class vehiculo {
    String marca;
    String año;
    String motor;
    private String frenos;

    public vehiculo(String marca, String año, String motor ) {
        this.marca = marca;
        this.año = año;
        this.motor = motor;
    }

    public vehiculo() {
    }

    public String getfrenos() {
        return frenos;
    }

    public void setfrenos(String frenos) {
        this.frenos = frenos;
    }
    
}
